package com.company;

import java.util.Scanner;

public class Sir {
    private static int aux;
    int[] b; //Cal de tras//
    int n;


    public static void swap(int b[], int x, int y) {
        int temp = b[x];
        b[x] = b[y];
        b[y] = temp;
    }

    public void quick(int[] b, int low, int high) {

        int middle = low + (high - low) / 2;
        int pivot = b[middle];


        int i = low, j = high;
        while (i <= j) {

            while (b[i] < pivot) {
                i++;
            }

            while (b[j] > pivot) {
                j--;
            }

            if (i <= j) {
                swap(b, i, j);
                i++;
                j--;
            }
        }

        if (low < j) {
            quick(b, low, j);
        }
        if (high > i) {
            quick(b, i, high);
        }

    }
}




