package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Sir ABC = new Sir();
        int[] a = new int[50];
        int[] b = new int[50];
        String d = "";
        boolean t = true;
        int n = 0;
        int[] aux = new int[1];
        System.out.println(
                "- C – iniţializează tabloul de sortat cu valori generate aleator \n" +
                        "- V - vizualizează tablou \n" +
                        "- R - reiniţializează tabloul: pentru aducerea tabloului la forma iniţială dupa ce acesta a fost sortat, în vederea aplicării unei alte sortări \n" +
                        "- S - sortare shellsort   \n" +
                        "- H - sortare heapsort    \n" +
                        "- Q- sortare quicksort    \n" +
                        "- X - părăsirea programului. \n ");
        Scanner sc = new Scanner(System.in);
        while (t) {
            System.out.print("Ce doriti?");
            String c = sc.nextLine();
            d = c.toLowerCase();
            switch (d) {

                case "c":
                    System.out.println("Introduceti numarul: ");
                    n = sc.nextInt();
                    ABC.setArray(a, b, n);
                    break;
                case "v":
                    ABC.getArray(b, n);
                    break;
                case "r":
                    ABC.reset(a, b, n);
                    break;
                case "s":
                    ABC.shell(b, n);
                    break;
                case "h":
                    ABC.heap(b, n);
                    break;
                case "q":
                    ABC.quick(b, 0, n - 1);
                    ABC.getArray(b, n);
                case "x":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Reintroduceti o litera valida");
                    break;
            }

        }

    }
}
